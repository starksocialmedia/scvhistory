#!/usr/bin/env python3
"""Rebuild links_out across inventory/legacy/*.json by merging related-reading sidebars.

Reads HTML from Reggie mirror first, falls back to live fetch. Commits nothing.
"""
from __future__ import annotations

import json
import re
import sys
import urllib.parse
import urllib.request
from pathlib import Path

REGGIE = Path("/Volumes/Reggie/SCVHistory/scvhistory.com")
LEGACY = Path(sys.argv[1] if len(sys.argv) > 1 else "/workspace/scvhistory/inventory/legacy")
UA = "SCVHistory-Legacy-Extract/1.0 (+rebuild_links_out)"

CHROME_ANCHORS = {
    "NEXT", "PREVIOUS", "CONTENTS", "SEARCH", "RETURN TO TOP", "RETURN TO MAIN INDEX",
    "PHOTO CREDITS", "BIBLIOGRAPHY", "BOOKS FOR SALE", "HOME", "TOP", "INDEX",
    "COMMENTS POWERED BY DISQUS.",
}
CHROME_HREF = re.compile(
    r"(?i)(key\.htm|bibliography\.htm|publications\.htm|googlesearch|disqus\.com)"
)

FILES = [
    "reynolds.json", "reynolds-full.json", "perkins.json", "worden.json",
    "oldtownnewhall.json", "warmemorial.json", "mentryville.json", "media.json",
    "coins.json", "loose-pages.json", "lw-features.json", "lw-film.json",
    "lw-disaster.json", "lw-remainder.json",
]


def is_internal(href: str) -> bool:
    if href.startswith("#") or href.startswith("mailto:"):
        return True
    if href.startswith("/") or not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", href):
        return True
    host = urllib.parse.urlparse(urllib.parse.urljoin("https://scvhistory.com/", href)).netloc
    return "scvhistory.com" in host or host == ""


def norm_path(href: str, base: str) -> str:
    absu = urllib.parse.urljoin(base or "https://scvhistory.com/", href or "")
    path = urllib.parse.unquote(urllib.parse.urlparse(absu).path or "").rstrip("/")
    path = re.sub(r"/index\.html?$", "", path, flags=re.I)
    return path.lower()


def url_to_reggie(url: str) -> Path | None:
    path = urllib.parse.unquote(urllib.parse.urlparse(url).path or "").lstrip("/")
    cand = REGGIE / path
    if cand.is_file():
        return cand
    for alt in (cand.with_suffix(".html"), cand.with_suffix(".htm")):
        if alt.is_file():
            return alt
    if cand.is_dir():
        for name in ("index.html", "index.htm"):
            if (cand / name).is_file():
                return cand / name
    return None


def fetch_live(url: str) -> str | None:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, timeout=45) as r:
            return r.read().decode("utf-8", "replace")
    except Exception:
        return None


def extract_related_reading_links(html: str, base_url: str = "") -> tuple[list[dict], str | None]:
    if not html or not re.search(r"inversecaption|thumbcaption", html, re.I):
        return [], None
    # Lightweight HTML parse via regex over candidate TDs that contain the classes
    header = None
    m = re.search(
        r'class=["\'][^"\']*inversecaption[^"\']*["\'][^>]*>(.*?)</(?:span|font|div|td)>',
        html,
        re.I | re.S,
    )
    if m:
        header = re.sub(r"<[^>]+>", " ", m.group(1))
        header = " ".join(header.split()) or None

    out: list[dict] = []
    # Find each <td>...</td> that contains inversecaption or thumbcaption class attrs
    for td_m in re.finditer(r"(?is)<td\b([^>]*)>(.*?)</td>", html):
        inner = td_m.group(2)
        if not re.search(r'class=["\'][^"\']*(?:inversecaption|thumbcaption)', inner, re.I):
            continue
        for am in re.finditer(r'(?is)<a\s+[^>]*href\s*=\s*["\']([^"\']+)["\'][^>]*>(.*?)</a>', inner):
            href_raw = am.group(1).strip()
            anchor = " ".join(re.sub(r"<[^>]+>", " ", am.group(2)).split())
            if not href_raw or href_raw.startswith("javascript:") or href_raw.startswith("mailto:"):
                continue
            if anchor.upper() in CHROME_ANCHORS:
                continue
            if CHROME_HREF.search(href_raw):
                continue
            if href_raw.startswith("#") and not anchor:
                continue
            out.append({
                "href_raw": href_raw,
                "anchor_text": anchor,
                "is_internal": is_internal(href_raw),
                "role": "related_reading",
            })
    seen: set[tuple[str, str]] = set()
    deduped: list[dict] = []
    for L in out:
        key = (norm_path(L["href_raw"], base_url), L["anchor_text"])
        if key in seen:
            continue
        seen.add(key)
        deduped.append(L)
    return deduped, header


def merge_links_out(existing: list[dict], related: list[dict], base_url: str) -> tuple[list[dict], int]:
    out = [dict(L) for L in (existing or [])]
    have = {norm_path(L.get("href_raw") or "", base_url) for L in out}
    added = 0
    for L in related or []:
        n = norm_path(L.get("href_raw") or "", base_url)
        if not n:
            continue
        if n in have:
            for e in out:
                if norm_path(e.get("href_raw") or "", base_url) == n and "role" not in e:
                    e["role"] = "related_reading"
                    break
            continue
        have.add(n)
        out.append(L)
        added += 1
    return out, added


def main() -> None:
    report = {"files": [], "pages_with_related_block": 0, "pages_gained_links": 0, "links_added": 0, "no_html": 0}
    for fname in FILES:
        path = LEGACY / fname
        if not path.exists():
            continue
        data = json.loads(path.read_text(encoding="utf-8"))
        pages = data.get("pages") or data.get("series_pages") or []
        # also handle related_pages in perkins-style
        extra_keys = []
        if "related_pages" in data and isinstance(data["related_pages"], list):
            extra_keys.append("related_pages")
        all_groups = [("pages", pages)]
        for k in extra_keys:
            all_groups.append((k, data[k]))

        file_block = file_gained = file_added = file_nohtml = 0
        for _key, group in all_groups:
            for page in group:
                url = page.get("source_url") or ""
                html = None
                src = None
                rp = url_to_reggie(url) if REGGIE.exists() else None
                if rp:
                    try:
                        html = rp.read_text(encoding="utf-8", errors="replace")
                        src = "reggie"
                    except Exception:
                        html = None
                if html is None and url:
                    html = fetch_live(url)
                    src = "live" if html else None
                if not html:
                    file_nohtml += 1
                    continue
                related, header = extract_related_reading_links(html, url)
                if not related:
                    continue
                file_block += 1
                new_links, added = merge_links_out(page.get("links_out") or [], related, url)
                page["links_out"] = new_links
                if header:
                    page["related_block_header_raw"] = header
                if added:
                    file_gained += 1
                    file_added += added
        # write back
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        report["files"].append({
            "file": fname,
            "pages_with_related_block": file_block,
            "pages_gained_links": file_gained,
            "links_added": file_added,
            "no_html": file_nohtml,
        })
        report["pages_with_related_block"] += file_block
        report["pages_gained_links"] += file_gained
        report["links_added"] += file_added
        report["no_html"] += file_nohtml
        print(f"{fname}: block={file_block} gained_pages={file_gained} links_added={file_added} no_html={file_nohtml}", flush=True)

    out_path = LEGACY / "links_out_rebuild_report.json"
    out_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print("TOTALS", {k: report[k] for k in ("pages_with_related_block", "pages_gained_links", "links_added", "no_html")})


if __name__ == "__main__":
    main()
